
function[d_hat] =  prediz(h,d)
    tab = readtable('previsioni_terzo_anno.xlsx');
    mat = tab{:,:};
    d = ceil(d/7);  % trovo il numero della domenica dato il giorno dell'anno
    d_hat = mat(h,d);
end