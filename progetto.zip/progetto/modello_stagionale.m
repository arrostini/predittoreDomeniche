clc
close all
clear

%% Lettura dati
tab = readtable('caricoDEhour.xlsx', 'Range','A2:D8762');
mat = tab{:,:};
solo_domenicheId = mat(mat(:,3)==1,:);

tab = readtable('caricoDEhour.xlsx', 'Range','A8763:D17522');
mat = tab{:,:};
solo_domenicheVal = mat(mat(:,3)==1,:);

%% Calcolo consumo orario medio per ciascuna delle 52 domeniche
consumiDomenicali = zeros(1,52);
for i= 1:52
    for j=1:24
        consumiDomenicali(i)= consumiDomenicali(i) + solo_domenicheId((i-1)*24+j,4);
    end
end
consumiDomenicali = consumiDomenicali/24;

%% Modellizzazione dei consumi orari medi per le 52 domeniche
domeniche = 1:1:52;
w3 = 2 * pi / 365;

% Detrendizzazione
phiDetrend = [ones(52,1), domeniche'];
[thetalsDetrend, devthetalsDetrend] = lscov(phiDetrend, consumiDomenicali');
consumiDomenicaliDetrend = consumiDomenicali' - phiDetrend*thetalsDetrend;
figure(2)
bar(consumiDomenicaliDetrend)
hold on

% Modellizzazione
phiFGiorni = [ cos(w3*domeniche'), sin(w3*domeniche'),  ...
     cos(2*w3*domeniche'), sin(2*w3*domeniche'), ...
     cos(3*w3*domeniche'), sin(3*w3*domeniche'), ...
     cos(4*w3*domeniche'), sin(4*w3*domeniche'), ...
     cos(5*w3*domeniche'), sin(5*w3*domeniche')
    ];
[thetalsFGiorni, devthetalsFGiorni] = lscov(phiFGiorni, consumiDomenicaliDetrend);
consumiDomenicaliModel = phiFGiorni * thetalsFGiorni;
plot(1:52, consumiDomenicaliModel);

 


%% Modellizzazione dei consumi medi per ciascuna delle 24 ore per le 4 stagioni
matConsumiOrari = [ solo_domenicheId(:,2) , solo_domenicheId(:,4)];
matConsumiInvernali = matConsumiOrari(1:24*8,:);
matConsumiInvernali = [matConsumiInvernali ; matConsumiOrari(24*47+1:24*52,:)];
matConsumiPrimaverili = matConsumiOrari(24*8+1:24*21,:);
matConsumiEstivi = matConsumiOrari(24*21+1:24*34,:);
matConsumiAutunnali = matConsumiOrari(24*34+1:24*52,:);

% Calcolo delle medie per le quattro stagioni 
mediaOrariaInvernale= zeros(1,24);
for i = 1:24
    mediaOrariaInvernale(i) = mean(matConsumiInvernali(matConsumiInvernali(:,1)==i,2));
end
mediaOrariaInvernaleDetrend = mediaOrariaInvernale - mean(mediaOrariaInvernale);

mediaOrariaPrimaverile= zeros(1,24);
for i = 1:24
    mediaOrariaPrimaverile(i) = mean(matConsumiPrimaverili(matConsumiPrimaverili(:,1)==i,2));
end
mediaOrariaPrimaverileDetrend = mediaOrariaPrimaverile - mean(mediaOrariaPrimaverile);

mediaOrariaAutunnale= zeros(1,24);
for i = 1:24
    mediaOrariaAutunnale(i) = mean(matConsumiAutunnali(matConsumiAutunnali(:,1)==i,2));
end
mediaOrariaAutunnaleDetrend = mediaOrariaAutunnale - mean(mediaOrariaAutunnale);

mediaOrariaEstiva= zeros(1,24);
for i = 1:24
    mediaOrariaEstiva(i) = mean(matConsumiEstivi(matConsumiEstivi(:,1)==i,2));
end
mediaOrariaEstivaDetrend = mediaOrariaEstiva - mean(mediaOrariaEstiva);


% Modello 
ore=1:1:24;
ore=ore';
w2 = 2 * pi / 24;
piFOre = [ cos(w2*ore), sin(w2*ore), ...
     cos(2*w2*ore), sin(2*w2*ore), ...
     cos(3*w2*ore), sin(3*w2*ore), ...
     cos(4*w2*ore), sin(4*w2*ore), ...
     cos(5*w2*ore), sin(5*w2*ore), ...
     cos(6*w2*ore), sin(6*w2*ore), ...
     cos(7*w2*ore), sin(7*w2*ore), ...
     cos(8*w2*ore), sin(8*w2*ore), ...
     cos(9*w2*ore), sin(9*w2*ore)
    ];

% Modellizzazione per le 4 stagioni
[thetalsFInv, devthetalsFInv] = lscov(piFOre, mediaOrariaInvernaleDetrend');
consumiInvernaliModel= piFOre * thetalsFInv;

[thetalsFPrim, devthetalsFPrim] = lscov(piFOre, mediaOrariaPrimaverileDetrend');
consumiPrimaveriliModel= piFOre * thetalsFPrim;

[thetalsFEst, devthetalsFEst] = lscov(piFOre, mediaOrariaEstivaDetrend');
consumiEstiviModel= piFOre * thetalsFEst;

[thetalsFAut, devthetalsFAut] = lscov(piFOre, mediaOrariaAutunnaleDetrend');
consumiAutunnaliModel= piFOre * thetalsFAut;

% Plot dei modelli stagionali
figure(7)
subplot(2,2,1)
bar(mediaOrariaPrimaverileDetrend)
hold on
title("Media oraria primaverile")
plot(1:1:24, consumiPrimaveriliModel);

subplot(2,2,2)
bar(mediaOrariaEstivaDetrend)
hold on
title("Media oraria estiva")
plot(1:1:24, consumiEstiviModel);

subplot(2,2,3)
bar(mediaOrariaAutunnaleDetrend)
hold on
title("Media oraria autunnale")
plot(1:1:24, consumiAutunnaliModel);

subplot(2,2,4)
bar(mediaOrariaInvernaleDetrend)
hold on
title("Media oraria invernale")
plot(1:1:24, consumiInvernaliModel);

%% Somma di modello sulle 24 ore e modello sulle 52 domeniche
consumiDetrendModelStagionale= zeros(52*24, 1);
for i= 1:8
    for j= 1:24
        consumiDetrendModelStagionale((i-1)*24+j)= consumiDomenicaliModel(i) + consumiInvernaliModel(j);
    end
end
for i= 9:21
    for j= 1:24
        consumiDetrendModelStagionale((i-1)*24+j)= consumiDomenicaliModel(i) + consumiPrimaveriliModel(j);
    end
end
for i= 22:34
    for j= 1:24
        consumiDetrendModelStagionale((i-1)*24+j)= consumiDomenicaliModel(i) + consumiEstiviModel(j);
    end
end
for i= 35:47
    for j= 1:24
        consumiDetrendModelStagionale((i-1)*24+j)= consumiDomenicaliModel(i) + consumiAutunnaliModel(j);
    end
end
for i= 48:52
    for j= 1:24
        consumiDetrendModelStagionale((i-1)*24+j)= consumiDomenicaliModel(i) + consumiInvernaliModel(j);
    end
end

%% Validazione
consumiDomenicaliVal = solo_domenicheVal(:,4);
giorni = solo_domenicheVal(:,1);
phiDetrendVal = [ones(52*24,1), giorni];
[thetalsDetrendVal, devthetalsDetrendVal] = lscov(phiDetrendVal, consumiDomenicaliVal);
trendVal = phiDetrendVal*thetalsDetrendVal;
previsioneStagionaleVal = consumiDetrendModelStagionale + trendVal;

%% Indicatori di performance
epsilonValStagionale = consumiDomenicaliVal - previsioneStagionaleVal;
ssrValStagionale = epsilonValStagionale' * epsilonValStagionale;
mseValStagionale = ssrValStagionale /1024;
rmsdValStagionale = sqrt(mseValStagionale);
range = (max(consumiDomenicaliVal)-min(consumiDomenicaliVal));
nrmsd_mediaValStagionale = (rmsdValStagionale / range ) *100;
nrmsd_rangeValStagionale = (rmsdValStagionale / mean(consumiDomenicaliVal)) *100;
maeValStagionale= mean(abs(epsilonValStagionale));

%% Plot degli errori
figure(11)
epsilonValStagionalePercent = (epsilonValStagionale./mean(consumiDomenicaliVal)).*100;
histogram(epsilonValStagionale)
figure(12)
histogram(abs(epsilonValStagionalePercent))

%% Stima del trend di lungo periodo
solo_domeniche = [solo_domenicheId; solo_domenicheVal];
consumi = solo_domeniche(:, 4);
ore = solo_domeniche(:, 2);
n = length(consumi);
giorni = (linspace(1, 104, n))';
phi = [ones(n, 1), giorni];
[thetals, devthetals] = lscov(phi, consumi);
giorni_3anni = (linspace(1, 156, n*3/2))';
trend = thetals(1, :) + giorni_3anni.*thetals(2,:);

%% Previsione finale ottenuta sommando modello detrendizzato a trend previsto
trend_previsto = trend(104*24+1:156*24,1);
stima_finale = trend_previsto + consumiDetrendModelStagionale;

%% Plot previsione
figure(1)
plot(giorni, consumi);
hold on

giorni_anno3 = (linspace(104, 156, n/2))';
plot(giorni_anno3, stima_finale, 'r');
hold on

plot(giorni_3anni, trend, 'k');

%% Salvataggio su file
mat_previsione = reshape(stima_finale,[24,52]);
xlswrite('previsioni_consumiStag.xlsx',mat_previsione)
